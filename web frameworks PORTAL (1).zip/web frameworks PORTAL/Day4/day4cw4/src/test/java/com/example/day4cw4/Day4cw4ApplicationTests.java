package com.example.day4cw4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day4cw4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
