package com.example.day2cw4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day2cw4Application {

	public static void main(String[] args) {
		SpringApplication.run(Day2cw4Application.class, args);
	}

}
