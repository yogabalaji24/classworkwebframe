package com.example.day6pah;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day6pahApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day6pahApplication.class, args);
	}

}
